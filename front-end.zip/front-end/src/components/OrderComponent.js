import './order.css';

const statuses = {
    0: 'Новый заказ',
    1: 'Аннулирован',
    2: 'Совершен'
};
export const OrderComponent = ({ className, fullInfo, status }) => {
    const { client, rooms } = fullInfo;
    return (<div className={`order-container ${className ? className : ''}`}>
        <div className={`order ${status == 0 ? 'order__status-new' : ''} `}>
            <div className="order__client">
                <h3>Клиент</h3>
                <div className="order__client-info ">
                    <span className="order__client-field">Имя:{client.name}</span>
                    <span className="order__client-field">Фамилия:{client.secondName}</span>
                    <span className="order__client-field">Телефон:{client.phone}</span>
                    <span className="order__client-field">mail:{client.email}</span>
                </div>
            </div>
            <div className="order__apartments">
                <div className="order__apartments-items">
                    <h3 className="order__apartments-header"><span>Квартиры</span><span> Статус : {statuses[status]}</span></h3>
                    {
                        rooms.map((room, index) => {
                            return (<div className="order__apartments-item" key={index}>
                                <span className="order__apartment-field">адрес:{room.address}</span>
                                <span className="order__apartment-field">кол-во гостей:{room.personsAmount}</span>
                                <span className="order__apartment-field">Наличие животных: {room.withAnimals ? 'Да' : 'Нет'}</span>
                                <span className="order__apartment-field">Дети:{room.withChilds ? 'Да' : 'Нет'}</span>
                                {/* TODO: сделать тут услуги из бд-ки */}
                                <span className="order__apartment-field">Услуги:</span>
                                <span className="order__apartment-field">Цена за апартаменты:{room.price}</span>
                                <span className="order__apartment-field">Цена c учетом услуг:{room.totalPrice}</span>

                            </div>)
                        })
                    }
                    <div className="order__status-btn-container">
                        <select className="order__status-selector">
                            {
                                Object.keys(statuses).map((statusId) => {
                                    return <option key={statusId}>{statuses[statusId]}</option>
                                })
                            }
                        </select>
                        <button className="order__status-btn">Сменить статус</button>
                    </div>
                    {/* <div className="order__apartments-item">
                        <span className="order__apartment-field">адрес:122</span>
                        <span className="order__apartment-field">кол-во гостей:122</span>
                        <span className="order__apartment-field">Наличие животных: нет</span>
                        <span className="order__apartment-field">Дети:нет</span>
                        <span className="order__apartment-field">Услуги:</span>
                    </div> */}
                </div>
            </div>
        </div>
    </div>);
}