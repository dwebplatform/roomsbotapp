import { useState, useEffect } from 'react'
import { OrderComponent } from './components/OrderComponent';
import { AspireComponent } from './components/AspireComponent';
import './App.css';


class ServiceUtil {

  async getAllOrders() {
    let response = await fetch('/api/order/all');
    let data = await response.json();
    return data;
  }
}
class ServiceDummy {
  async getAllOrders() {
    return { "status": "ok", "orders": [{ "fullInfo": { "client": { "name": "Bob", "secondname": "", "email": "karpov-vb-1996@mail.ru", "phone": 8808555 }, "rooms": [{ "id": 1, "address": "ул Тушинская дом 3 кв 67", "price": 2800, "roomAmount": 3, "services": "['Уборка','Стирка','Гладка']", "withChilds": true, "withAnimals": false }] }, "id": 5, "status": 0, "createdAt": "2021-01-24T13:39:23.000Z", "updatedAt": "2021-01-24T13:39:23.000Z" }, { "fullInfo": { "client": { "name": "Bob", "secondname": "Marlie", "email": "karpov-vb-1996@mail.ru", "phone": 8808555 }, "rooms": [{ "id": 1, "address": "ул Тушинская дом 3 кв 67", "price": 2800, "roomAmount": 3, "services": "['Уборка','Стирка','Гладка']", "withChilds": true, "withAnimals": false }] }, "id": 11, "status": 0, "createdAt": "2021-01-24T14:01:39.000Z", "updatedAt": "2021-01-24T14:01:39.000Z" }, { "fullInfo": { "client": { "name": "Bob", "secondname": "Marlie", "email": "karpov-vb-1996@mail.ru", "phone": 8808555 }, "rooms": [{ "id": 1, "address": "ул Тушинская дом 3 кв 67", "price": 2800, "personsAmount": 3, "roomAmount": 3, "services": "['Уборка','Стирка','Гладка']", "withChilds": true, "withAnimals": false }] }, "id": 12, "status": 0, "createdAt": "2021-01-24T14:07:52.000Z", "updatedAt": "2021-01-24T14:07:52.000Z" }] }

  }
}

function App() {

  const [orders, setOrders] = useState([]);
  const isDummy = false;

  let service = null;
  if (isDummy) {
    service = new ServiceDummy();
  } else {
    service = new ServiceUtil();
  }
  useEffect(() => {
    async function getAllOrders() {
      //TODO: check protected
      try {
        let data = await service.getAllOrders();
        console.log(data)
        if (data.status == 'ok') {
          setOrders(data.orders);
        }
      } catch (e) {
        console.log(e)
      }
    }
    getAllOrders();
  }, []);
  return (
    <div className="App">
      {/* TODO: сделать поиск по статусам по дате создания  по дефолту показывать только те, которые актуальны*/}

      <AspireComponent />
      <main className="main-container">
        {
          orders && orders.map((item, i) => {
            return <OrderComponent className="main-container__item" fullInfo={item.fullInfo} status={item.status} key={i} />
          })
        }
      </main>
    </div>
  );
}

export default App;
