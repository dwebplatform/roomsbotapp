export const AspireComponent = () => {
    return (<div style={{
        position: 'fixed',
        top: 0,
        zIndex: 10,
        left: '85%',

    }}>
        <img style={{
            width: '200px',
            borderRadius: '50%',
            height: '200px'
        }} src="https://i.pinimg.com/originals/32/62/b5/3262b55de055134f1a10f886c30c808f.jpg" />
    </div>);
}